# ZapMC Ticket Bot

A Discord.js v14 ticket bot with:

- Professional support panel
- 9 ticket categories
- Discord modal forms
- Automatic private ticket channels
- Claim / Unclaim
- Handler assignment
- Ping Handler button
- Rename button
- Add / Remove user buttons
- Close confirmation
- HTML transcripts
- Ticket logs
- SQLite persistence
- Staff-only ticket controls
- Member mention restrictions
- `/setup-ticket` slash command

## Requirements

- Node.js 20+
- A Discord application/bot
- The bot invited with `bot` and `applications.commands` scopes
- Bot permissions:
  - View Channels
  - Send Messages
  - Embed Links
  - Attach Files
  - Read Message History
  - Manage Channels
  - Manage Messages
  - Mention Everyone (only needed so the bot can ping an assigned handler)
  - Manage Roles is NOT required

## Setup

1. Rename `.env.example` to `.env`.
2. Fill in TOKEN, CLIENT_ID, GUILD_ID, SUPPORT_ROLE_ID, TICKET_CATEGORY_ID and LOG_CHANNEL_ID.
3. Run:
   npm install
   npm start
4. In your Discord server, run:
   /setup-ticket

The command creates the panel in the channel where you run it.

## Ticket categories

- Store
- General Support
- Player Report
- Hacker Report
- Item Refund
- Punishment Appeal
- Staff Report
- Bug Report
- Media Application

## Hosting on a VPS

Ubuntu/Debian:

sudo apt update
sudo apt install -y curl unzip
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

Upload the ZIP and extract it:

unzip insane-ticket-bot.zip
cd insane-ticket-bot

Install packages:

npm install

Create environment file:

cp .env.example .env
nano .env

Start:

npm start

For 24/7 hosting with PM2:

sudo npm install -g pm2
pm2 start src/index.js --name insane-ticket-bot
pm2 save
pm2 startup

Run the command printed by PM2.

Useful commands:

pm2 status
pm2 logs insane-ticket-bot
pm2 restart insane-ticket-bot
pm2 stop insane-ticket-bot

## Important

Never post your bot token in Discord or send it to anyone.


## Configured Application ID

The `.env.example` already contains the provided Application/Client ID `1555991962304249896`. Do NOT put a bot token in this ZIP or share it in chat. Generate/reset the token in Discord Developer Portal and put the new token only in the VPS `.env` file.
