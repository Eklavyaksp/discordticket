const {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder
} = require("discord.js");

const db = require("./database");
const config = require("./config");

const CATEGORIES = {
  store: {
    label: "Store",
    emoji: "🛒",
    fields: [
      ["Minecraft username", "username", "Your exact in-game username", false],
      ["Order / transaction ID", "order", "Enter your order or transaction ID", false],
      ["What do you need help with?", "issue", "Explain your store issue", true]
    ]
  },
  general: {
    label: "General Support",
    emoji: "🎟️",
    fields: [
      ["Minecraft username", "username", "Your exact in-game username", false],
      ["Your platform", "platform", "Java or Pocket", false],
      ["Please explain your issue", "issue", "Tell us what happened and what help you need", true]
    ]
  },
  player_report: {
    label: "Player Report",
    emoji: "⚠️",
    fields: [
      ["Your Minecraft username", "username", "Your exact username", false],
      ["Reported player", "reported", "Username of the player you are reporting", false],
      ["Reason", "reason", "Explain what happened", true]
    ]
  },
  hacker_report: {
    label: "Hacker Report",
    emoji: "🚨",
    fields: [
      ["Your Minecraft username", "username", "Your exact username", false],
      ["Suspected hacker", "suspect", "Username of the suspected player", false],
      ["Evidence / description", "evidence", "Describe the incident and evidence you have", true]
    ]
  },
  item_refund: {
    label: "Item Refund",
    emoji: "📦",
    fields: [
      ["Minecraft username", "username", "Your exact username", false],
      ["Item(s)", "items", "What item(s) are involved?", false],
      ["Reason", "reason", "Explain why you are requesting a refund", true]
    ]
  },
  punishment_appeal: {
    label: "Punishment Appeal",
    emoji: "🔨",
    fields: [
      ["Minecraft username", "username", "Your exact username", false],
      ["Punishment", "punishment", "Ban, mute, warning, etc.", false],
      ["Why should it be reviewed?", "reason", "Explain your appeal", true]
    ]
  },
  staff_report: {
    label: "Staff Report",
    emoji: "🛡️",
    fields: [
      ["Your Minecraft username", "username", "Your exact username", false],
      ["Staff member", "staff", "Name of the staff member", false],
      ["Report details", "reason", "Explain what happened", true]
    ]
  },
  bug_report: {
    label: "Bug Report",
    emoji: "🌐",
    fields: [
      ["Minecraft username", "username", "Your exact username", false],
      ["Bug title", "bug", "Short name for the bug", false],
      ["Steps / description", "steps", "Explain how the bug happens", true]
    ]
  },
  media_application: {
    label: "Media Application",
    emoji: "📡",
    fields: [
      ["Minecraft username", "username", "Your exact username", false],
      ["Platform / channel", "platform", "YouTube, TikTok, Twitch, etc.", false],
      ["Channel / profile link", "link", "Paste your public profile link", false],
      ["Additional information", "info", "Tell us about your content", true]
    ]
  }
};

function ticketButtons() {
  return [
    new ActionRowBuilder().addComponents(
      button("ticket:store", "🛒 Store"),
      button("ticket:general", "🎟️ General Support"),
      button("ticket:player_report", "⚠️ Player Report"),
      button("ticket:hacker_report", "🚨 Hacker Report"),
      button("ticket:item_refund", "📦 Item Refund")
    ),
    new ActionRowBuilder().addComponents(
      button("ticket:punishment_appeal", "🔨 Punishment Appeal"),
      button("ticket:staff_report", "🛡️ Staff Report"),
      button("ticket:bug_report", "🌐 Bug Report"),
      button("ticket:media_application", "📡 Media Application")
    )
  ];
}

function button(id, label, style = ButtonStyle.Secondary) {
  return new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
}

function controlButtons() {
  return [
    new ActionRowBuilder().addComponents(
      button("control:claim", "🛡️ Claim", ButtonStyle.Success),
      button("control:unclaim", "🔓 Unclaim", ButtonStyle.Secondary),
      button("control:ping", "🔔 Ping Handler", ButtonStyle.Primary),
      button("control:rename", "✏️ Rename", ButtonStyle.Secondary)
    ),
    new ActionRowBuilder().addComponents(
      button("control:add", "➕ Add User", ButtonStyle.Secondary),
      button("control:remove", "➖ Remove User", ButtonStyle.Secondary),
      button("control:close", "🔒 Close", ButtonStyle.Danger)
    )
  ];
}

function setupEmbed() {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("ZapMC | Support")
    .setDescription(
      "**Need help from Staff? Need to report somebody?**\n" +
      "Open a ticket by clicking the correct button below.\n\n" +
      "**Available support tickets:**\n" +
      "🛒 Store\n" +
      "🎟️ General Support\n" +
      "⚠️ Player Report\n" +
      "🚨 Hacker Report\n" +
      "📦 Item Refund\n" +
      "🔨 Punishment Appeal\n" +
      "🛡️ Staff Report\n" +
      "🌐 Bug Report\n" +
      "📡 Media Application\n\n" +
      "Please create only one ticket for the same issue and provide complete information."
    )
    .setFooter({ text: "ZapMC Support — Ticketing without the clutter" });
}

async function createTicket(interaction, type, answers) {
  const existing = db.getOpenByUser(interaction.guild.id, interaction.user.id);
  if (existing.length > 0) {
    return interaction.reply({
      content: `❌ You already have an open ticket: <#${existing[0].channel_id}>`,
      ephemeral: true
    });
  }

  const cat = CATEGORIES[type];
  const safeName = interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 18) || "user";
  const channelName = `${config.ticketPrefix}-${type}-${safeName}`.slice(0, 100);

  const overwrites = [
    {
      id: interaction.guild.id,
      deny: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.MentionEveryone
      ]
    },
    {
      id: interaction.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles
      ],
      deny: [PermissionFlagsBits.MentionEveryone]
    },
    {
      id: config.supportRoleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.ManageMessages
      ],
      deny: [PermissionFlagsBits.MentionEveryone]
    },
    {
      id: interaction.client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.MentionEveryone
      ]
    }
  ];

  const channel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: config.ticketCategoryId,
    topic: `Ticket | ${cat.label} | ${interaction.user.id}`,
    permissionOverwrites: overwrites,
    reason: `New ${cat.label} ticket by ${interaction.user.tag}`
  });

  const answersText = Object.entries(answers)
    .map(([key, value]) => `**${key}:** ${String(value).slice(0, 1000)}`)
    .join("\n");

  db.create({
    channel_id: channel.id,
    guild_id: interaction.guild.id,
    user_id: interaction.user.id,
    category: type,
    username: answers.username || "",
    platform: answers.platform || "",
    issue: answers.issue || answers.reason || answers.evidence || answers.steps || answers.info || "",
    created_at: Date.now()
  });

  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(`${cat.emoji} ${cat.label}`)
    .setDescription(
      `Hello <@${interaction.user.id}> 👋\n\n` +
      `Thank you for contacting **ZapMC Support**.\n` +
      `A member of our support team will assist you shortly.\n\n` +
      `**Ticket Information**\n` +
      `👤 Created by: <@${interaction.user.id}>\n` +
      `📂 Category: ${cat.label}\n` +
      `🛡️ Handler: Not Claimed\n\n` +
      `**Submitted Information**\n${answersText}`
    )
    .setFooter({ text: "Please keep all information related to this issue in this ticket." })
    .setTimestamp();

  await channel.send({
    content: `<@${interaction.user.id}> <@&${config.supportRoleId}>`,
    embeds: [embed],
    components: controlButtons(),
    allowedMentions: {
      users: [interaction.user.id],
      roles: [config.supportRoleId]
    }
  });

  await interaction.reply({
    content: `✅ Your ticket has been created: ${channel}`,
    ephemeral: true
  });

  const logChannel = interaction.guild.channels.cache.get(config.logChannelId);
  if (logChannel) {
    await logChannel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle("🎟️ Ticket Created")
          .addFields(
            { name: "User", value: `<@${interaction.user.id}>`, inline: true },
            { name: "Category", value: cat.label, inline: true },
            { name: "Channel", value: `${channel}`, inline: true }
          )
          .setTimestamp()
      ]
    });
  }
}

module.exports = {
  CATEGORIES,
  ticketButtons,
  setupEmbed,
  controlButtons,
  createTicket
};
