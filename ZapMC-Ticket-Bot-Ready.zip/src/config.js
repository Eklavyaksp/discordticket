require("dotenv").config();

const required = [
  "TOKEN",
  "CLIENT_ID",
  "GUILD_ID",
  "SUPPORT_ROLE_ID"
];

for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Missing required .env value: ${key}`);
  }
}

module.exports = {
  token: process.env.TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  supportRoleId: process.env.SUPPORT_ROLE_ID,
  ticketCategoryId: process.env.TICKET_CATEGORY_ID || "",
  logChannelId: process.env.LOG_CHANNEL_ID || "",
  mediaRoleId: process.env.MEDIA_ROLE_ID || "",
  reportRoleId: process.env.REPORT_ROLE_ID || "",
  ticketPrefix: process.env.TICKET_PREFIX || "ticket",
  panelChannelId: process.env.PANEL_CHANNEL_ID || ""
};
