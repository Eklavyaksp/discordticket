const Database = require("better-sqlite3");
const fs = require("fs");
const path = require("path");

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "tickets.sqlite"));

db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS tickets (
  channel_id TEXT PRIMARY KEY,
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  category TEXT NOT NULL,
  username TEXT,
  platform TEXT,
  issue TEXT,
  claimed_by TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  created_at INTEGER NOT NULL,
  closed_at INTEGER
);
`);

const insert = db.prepare(`
INSERT INTO tickets
(channel_id, guild_id, user_id, category, username, platform, issue, claimed_by, status, created_at)
VALUES (@channel_id, @guild_id, @user_id, @category, @username, @platform, @issue, NULL, 'open', @created_at)
`);

const getByChannel = db.prepare(`SELECT * FROM tickets WHERE channel_id = ?`);
const getOpenByUser = db.prepare(`SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open'`);
const claim = db.prepare(`UPDATE tickets SET claimed_by = ? WHERE channel_id = ?`);
const unclaim = db.prepare(`UPDATE tickets SET claimed_by = NULL WHERE channel_id = ?`);
const close = db.prepare(`UPDATE tickets SET status = 'closed', closed_at = ? WHERE channel_id = ?`);

module.exports = {
  create(data) { insert.run(data); },
  get(channelId) { return getByChannel.get(channelId); },
  getOpenByUser(guildId, userId) { return getOpenByUser.all(guildId, userId); },
  claim(channelId, userId) { claim.run(userId, channelId); },
  unclaim(channelId) { unclaim.run(channelId); },
  close(channelId) { close.run(Date.now(), channelId); }
};
