const {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
  REST,
  Routes,
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType
} = require("discord.js");

const discordTranscripts = require("discord-html-transcripts");
const config = require("./config");
const db = require("./database");
const {
  CATEGORIES,
  ticketButtons,
  setupEmbed,
  controlButtons,
  createTicket
} = require("./tickets");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

const commands = [
  new SlashCommandBuilder()
    .setName("setup-ticket")
    .setDescription("Create the support ticket panel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .toJSON()
];

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(config.token);
  await rest.put(
    Routes.applicationGuildCommands(config.clientId, config.guildId),
    { body: commands }
  );
  console.log("Slash commands registered.");
}

function hasStaff(interaction) {
  return interaction.member?.roles?.cache?.has(config.supportRoleId) ||
    interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild);
}

function buildModal(type) {
  const cat = CATEGORIES[type];

  const modal = new ModalBuilder()
    .setCustomId(`modal:${type}`)
    .setTitle(`Open ${cat.label}`.slice(0, 45));

  for (const [label, id, placeholder, paragraph] of cat.fields) {
    const input = new TextInputBuilder()
      .setCustomId(id)
      .setLabel(label.slice(0, 45))
      .setPlaceholder(placeholder.slice(0, 100))
      .setRequired(true)
      .setStyle(paragraph ? TextInputStyle.Paragraph : TextInputStyle.Short)
      .setMaxLength(paragraph ? 1000 : 100);

    modal.addComponents(new ActionRowBuilder().addComponents(input));
  }

  return modal;
}

function controlModal(customId, title, label, placeholder, style = TextInputStyle.Short) {
  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle(title);

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId("value")
        .setLabel(label)
        .setPlaceholder(placeholder)
        .setStyle(style)
        .setRequired(true)
        .setMaxLength(style === TextInputStyle.Paragraph ? 500 : 100)
    )
  );

  return modal;
}

async function closeTicket(interaction) {
  const ticket = db.get(interaction.channel.id);
  if (!ticket) {
    return interaction.reply({ content: "❌ This is not a managed ticket.", ephemeral: true });
  }

  const transcript = await discordTranscripts.createTranscript(interaction.channel, {
    limit: -1,
    filename: `${interaction.channel.name}.html`,
    saveImages: true,
    poweredBy: false
  });

  const logChannel = interaction.guild.channels.cache.get(config.logChannelId);

  if (logChannel) {
    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setTitle("🔒 Ticket Closed")
      .addFields(
        { name: "Ticket", value: interaction.channel.name, inline: true },
        { name: "Created By", value: `<@${ticket.user_id}>`, inline: true },
        { name: "Closed By", value: `<@${interaction.user.id}>`, inline: true },
        { name: "Category", value: CATEGORIES[ticket.category]?.label || ticket.category, inline: true }
      )
      .setTimestamp();

    await logChannel.send({ embeds: [embed], files: [transcript] });
  }

  db.close(interaction.channel.id);

  await interaction.reply({
    content: "🔒 Ticket closed. The transcript has been sent to the ticket log.",
    ephemeral: true
  });

  setTimeout(() => interaction.channel.delete("Ticket closed"), 3000);
}

client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  console.log(`Serving ${client.guilds.cache.size} guild(s)`);
  try {
    await ensureInfrastructure();
  } catch (err) {
    console.error("Infrastructure setup failed:", err);
  }
});

client.on("interactionCreate", async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "setup-ticket") {
        const embed = setupEmbed();
        const panelChannel = config.panelChannelId
          ? interaction.guild.channels.cache.get(config.panelChannelId)
          : interaction.channel;

        if (!panelChannel || panelChannel.type !== ChannelType.GuildText) {
          return interaction.reply({
            content: "❌ Configured panel channel was not found.",
            ephemeral: true
          });
        }

        await panelChannel.send({
          embeds: [embed],
          components: ticketButtons()
        });

        return interaction.reply({
          content: "✅ Ticket panel created.",
          ephemeral: true
        });
      }
    }

    if (interaction.isButton()) {
      if (interaction.customId === "close:confirm") {
        if (!hasStaff(interaction)) {
          return interaction.reply({ content: "❌ Staff only.", ephemeral: true });
        }
        return closeTicket(interaction);
      }

      if (interaction.customId === "close:cancel") {
        return interaction.update({ content: "Cancelled.", components: [] });
      }

      if (interaction.customId.startsWith("ticket:")) {
        const type = interaction.customId.split(":")[1];
        if (!CATEGORIES[type]) return;
        return interaction.showModal(buildModal(type));
      }

      if (!interaction.customId.startsWith("control:")) return;

      const ticket = db.get(interaction.channel.id);
      if (!ticket) {
        return interaction.reply({ content: "❌ This is not a managed ticket.", ephemeral: true });
      }

      const action = interaction.customId.split(":")[1];

      if (["claim", "unclaim", "ping", "rename", "add", "remove", "close"].includes(action) && !hasStaff(interaction)) {
        return interaction.reply({
          content: "❌ Only support staff can use ticket controls.",
          ephemeral: true
        });
      }

      if (action === "claim") {
        if (ticket.claimed_by) {
          return interaction.reply({
            content: `⚠️ This ticket is already claimed by <@${ticket.claimed_by}>.`,
            ephemeral: true
          });
        }

        db.claim(interaction.channel.id, interaction.user.id);

        const embed = new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle("🛡️ Ticket Claimed")
          .setDescription(`This ticket has been claimed by <@${interaction.user.id}>.\n\nThe assigned handler will assist you shortly.`)
          .setTimestamp();

        await interaction.channel.send({
          embeds: [embed],
          allowedMentions: { users: [interaction.user.id] }
        });

        return interaction.reply({ content: "✅ Ticket claimed.", ephemeral: true });
      }

      if (action === "unclaim") {
        if (!ticket.claimed_by) {
          return interaction.reply({ content: "⚠️ This ticket is not currently claimed.", ephemeral: true });
        }
        if (ticket.claimed_by !== interaction.user.id && !interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
          return interaction.reply({ content: "❌ Only the current handler or a server manager can unclaim this ticket.", ephemeral: true });
        }
        db.unclaim(interaction.channel.id);
        await interaction.channel.send({
          embeds: [new EmbedBuilder()
            .setColor(0xFEE75C)
            .setTitle("🔓 Ticket Unclaimed")
            .setDescription("This ticket is now available for another staff member to claim.")
            .setTimestamp()]
        });
        return interaction.reply({ content: "🔓 Ticket unclaimed.", ephemeral: true });
      }

      if (action === "ping") {
        if (!ticket.claimed_by) {
          return interaction.reply({
            content: "⚠️ This ticket has not been claimed yet.",
            ephemeral: true
          });
        }

        await interaction.channel.send({
          content: `<@${ticket.claimed_by}>`,
          embeds: [
            new EmbedBuilder()
              .setColor(0x5865F2)
              .setTitle("🔔 Handler Ping")
              .setDescription(`<@${ticket.user_id}> has requested the assigned handler's attention.`)
              .setTimestamp()
          ],
          allowedMentions: { users: [ticket.claimed_by] }
        });

        return interaction.reply({ content: "🔔 Handler pinged.", ephemeral: true });
      }

      if (action === "rename") {
        return interaction.showModal(
          controlModal(
            "controlmodal:rename",
            "Rename Ticket",
            "New ticket name",
            "Example: payment-issue"
          )
        );
      }

      if (action === "add") {
        return interaction.showModal(
          controlModal(
            "controlmodal:add",
            "Add User",
            "User ID",
            "Paste the Discord user ID"
          )
        );
      }

      if (action === "remove") {
        return interaction.showModal(
          controlModal(
            "controlmodal:remove",
            "Remove User",
            "User ID",
            "Paste the Discord user ID"
          )
        );
      }

      if (action === "close") {
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("close:confirm")
            .setLabel("🔒 Close Ticket")
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId("close:cancel")
            .setLabel("Cancel")
            .setStyle(ButtonStyle.Secondary)
        );

        return interaction.reply({
          content: "⚠️ Are you sure you want to close this ticket?",
          components: [row],
          ephemeral: true
        });
      }
    }


    if (interaction.isModalSubmit()) {
      if (interaction.customId.startsWith("modal:")) {
        const type = interaction.customId.split(":")[1];
        const cat = CATEGORIES[type];

        const answers = {};
        for (const [, id] of cat.fields) {
          answers[id] = interaction.fields.getTextInputValue(id);
        }

        return createTicket(interaction, type, answers);
      }

      if (interaction.customId === "controlmodal:rename") {
        if (!hasStaff(interaction)) return interaction.reply({ content: "❌ Staff only.", ephemeral: true });

        let name = interaction.fields.getTextInputValue("value")
          .toLowerCase()
          .replace(/[^a-z0-9-]/g, "-")
          .replace(/-+/g, "-")
          .replace(/^-|-$/g, "")
          .slice(0, 90);

        if (!name) name = "ticket";

        await interaction.channel.setName(`${config.ticketPrefix}-${name}`.slice(0, 100));
        return interaction.reply({ content: `✅ Renamed to \`${interaction.channel.name}\`.`, ephemeral: true });
      }

      if (interaction.customId === "controlmodal:add" || interaction.customId === "controlmodal:remove") {
        if (!hasStaff(interaction)) return interaction.reply({ content: "❌ Staff only.", ephemeral: true });

        const id = interaction.fields.getTextInputValue("value").replace(/[<@!>]/g, "").trim();
        const member = await interaction.guild.members.fetch(id).catch(() => null);

        if (!member) {
          return interaction.reply({ content: "❌ I couldn't find that member. Use their numeric Discord ID.", ephemeral: true });
        }

        if (interaction.customId === "controlmodal:add") {
          await interaction.channel.permissionOverwrites.edit(member.id, {
            ViewChannel: true,
            SendMessages: true,
            ReadMessageHistory: true,
            AttachFiles: true,
            MentionEveryone: false
          });

          return interaction.reply({ content: `✅ Added ${member} to this ticket.`, ephemeral: true });
        } else {
          if (member.id === ticketOwnerId(interaction.channel.id)) {
            return interaction.reply({ content: "❌ You cannot remove the ticket creator.", ephemeral: true });
          }

          await interaction.channel.permissionOverwrites.delete(member.id);
          return interaction.reply({ content: `✅ Removed ${member} from this ticket.`, ephemeral: true });
        }
      }
    }
  } catch (error) {
    console.error(error);

    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: "❌ Something went wrong while processing that action. Check the bot console.",
        ephemeral: true
      }).catch(() => {});
    }
  }
});

function ticketOwnerId(channelId) {
  const ticket = db.get(channelId);
  return ticket?.user_id;
}


async function ensureInfrastructure() {
  const guild = client.guilds.cache.get(config.guildId);
  if (!guild) throw new Error("Bot is not in the configured guild.");

  // Automatically find/create the ticket category.
  if (!config.ticketCategoryId) {
    let category = guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory && c.name === "🎫・TICKETS"
    );
    if (!category) {
      category = await guild.channels.create({
        name: "🎫・TICKETS",
        type: ChannelType.GuildCategory,
        reason: "ZapMC Ticket Bot infrastructure"
      });
    }
    config.ticketCategoryId = category.id;
  }

  // Automatically find/create the log channel.
  if (!config.logChannelId) {
    let logs = guild.channels.cache.find(
      c => c.type === ChannelType.GuildText && c.name === "📋・ticket-logs"
    );
    if (!logs) {
      logs = await guild.channels.create({
        name: "📋・ticket-logs",
        type: ChannelType.GuildText,
        reason: "ZapMC Ticket Bot ticket logs"
      });
    }
    config.logChannelId = logs.id;
  }

  console.log(`Ticket category: ${config.ticketCategoryId}`);
  console.log(`Ticket logs: ${config.logChannelId}`);
}

registerCommands()
  .then(() => client.login(config.token))
  .catch(error => {
    console.error("Startup failed:", error);
    process.exit(1);
  });
